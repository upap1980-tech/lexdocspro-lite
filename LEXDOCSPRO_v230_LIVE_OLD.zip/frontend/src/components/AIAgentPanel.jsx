import React from 'react';
import { Search, Brain, Send, History, Paperclip, Minimize2 } from 'lucide-react';

const AIContextItem = ({ label, value }) => (
    <div className="flex justify-between items-center py-2 border-b border-slate-800/50">
        <span className="text-[10px] uppercase font-mono text-slate-500">{label}</span>
        <span className="text-xs text-slate-200 font-medium">{value}</span>
    </div>
);

const AIAgentPanel = () => {
    return (
        <div className="p-8 mt-16 ml-64 bg-industrial-dark min-h-screen flex gap-6">
            <div className="flex-1 flex flex-col bg-industrial-card border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
                <div className="p-4 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-industrial-accent/20 flex items-center justify-center text-industrial-accent">
                            <Brain size={18} />
                        </div>
                        <div>
                            <h3 className="text-sm font-bold text-white">AI Agent v3.0</h3>
                            <p className="text-[10px] text-industrial-success font-mono uppercase tracking-widest">En línea / Contexto Activo</p>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <button className="p-2 hover:bg-slate-800 rounded-lg text-slate-500 transition-colors">
                            <Minimize2 size={16} />
                        </button>
                    </div>
                </div>

                <div className="flex-1 p-6 space-y-6 overflow-y-auto custom-scrollbar">
                    <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-industrial-accent flex-shrink-0 flex items-center justify-center text-white font-bold text-xs">AI</div>
                        <div className="bg-slate-800/50 rounded-2xl p-4 max-w-[80%] border border-slate-700/30">
                            <p className="text-sm text-slate-200 leading-relaxed">
                                Hola. He analizado el expediente **#DOC-456 (López vs. Banco Central)**.
                                Basado en las notas de estrategia de ayer, sugiero redactar una **Contestación a la Demanda** centrada en la falta de transparencia en los intereses.
                            </p>
                            <div className="mt-3 flex gap-2">
                                <button className="text-[10px] px-3 py-1 bg-industrial-accent hover:bg-blue-600 text-white rounded-full font-bold transition-all">Auto-Draft</button>
                                <button className="text-[10px] px-3 py-1 border border-slate-700 hover:border-slate-500 text-slate-400 rounded-full font-bold transition-all">Ver Notas</button>
                            </div>
                        </div>
                    </div>

                    <div className="flex gap-4 flex-row-reverse">
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex-shrink-0 flex items-center justify-center text-white font-bold text-xs">YO</div>
                        <div className="bg-industrial-accent/10 rounded-2xl p-4 max-w-[80%] border border-industrial-accent/20">
                            <p className="text-sm text-slate-200">Perfecto. Asegúrate de citar la sentencia del TS de 2023 sobre tarjetas revolving.</p>
                        </div>
                    </div>
                </div>

                <div className="p-6 bg-industrial-dark/50 border-t border-slate-800">
                    <div className="flex items-center gap-3 bg-industrial-card border border-slate-700 rounded-2xl p-2 pl-4 shadow-xl">
                        <Search className="text-slate-500" size={18} />
                        <input
                            type="text"
                            placeholder="Instrucciones adicionales para el agente..."
                            className="flex-1 bg-transparent border-none outline-none text-sm text-slate-200"
                        />
                        <div className="flex gap-1">
                            <button className="p-2 text-slate-500 hover:text-white transition-colors"><Paperclip size={18} /></button>
                            <button className="bg-industrial-accent p-2 rounded-xl text-white hover:bg-blue-600 shadow-lg shadow-industrial-accent/20 transition-all">
                                <Send size={18} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="w-80 space-y-6">
                <div className="bg-industrial-card border border-slate-800 p-6 rounded-3xl">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <History size={14} /> Contexto del Caso
                    </h4>
                    <div className="space-y-1">
                        <AIContextItem label="Expediente" value="#DOC-456" />
                        <AIContextItem label="Cliente" value="López García, M." />
                        <AIContextItem label="Juzgado" value="1ª Instancia nº 2" />
                        <AIContextItem label="Procedimiento" value="Ordinario" />
                    </div>
                    <div className="mt-6">
                        <label className="text-[10px] text-slate-500 uppercase font-mono mb-2 block">Tonalidad del Agente</label>
                        <div className="grid grid-cols-3 gap-2">
                            <button className="text-[9px] font-bold py-1.5 rounded-lg border border-slate-700 text-slate-400 hover:border-industrial-accent hover:text-white transition-all">Agresivo</button>
                            <button className="text-[9px] font-bold py-1.5 rounded-lg bg-industrial-accent text-white border border-industrial-accent">Neutral</button>
                            <button className="text-[9px] font-bold py-1.5 rounded-lg border border-slate-700 text-slate-400 hover:border-industrial-accent hover:text-white transition-all">Formal</button>
                        </div>
                    </div>
                </div>

                <div className="bg-gradient-to-br from-indigo-900/40 to-slate-900 border border-indigo-500/30 p-6 rounded-3xl">
                    <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest mb-2">Sugerencia Proactiva</p>
                    <p className="text-xs text-slate-300 leading-relaxed italic">
                        "He detectado un documento similar firmado hace 3 meses. ¿Deseas aplicar los mismos fundamentos legales?"
                    </p>
                </div>
            </div>
        </div>
    );
};

export default AIAgentPanel;
