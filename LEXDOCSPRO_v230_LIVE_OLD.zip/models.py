"""
Modelos de base de datos para LexDocsPro LITE v2.0
Gestión de usuarios y autenticación
"""
import sqlite3
from datetime import datetime
from typing import Optional, Dict, List

class DatabaseManager:
    """Gestor de base de datos principal"""
    
    def __init__(self, db_path='lexdocs.db'):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        """Inicializar tablas de base de datos"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Tabla de usuarios
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                rol TEXT DEFAULT 'LECTURA',
                nombre TEXT,
                activo BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP
            )
        ''')
        
        # Tabla de sesiones/tokens (para blacklist de JWT)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS token_blacklist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                jti TEXT UNIQUE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Tabla de auditoría
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action TEXT NOT NULL,
                endpoint TEXT,
                ip_address TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        # Tabla de documentos pendientes de revisión
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pending_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                temp_file_path TEXT NOT NULL,
                original_filename TEXT NOT NULL,
                extracted_data TEXT,
                proposed_data TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                processed_by INTEGER,
                FOREIGN KEY (processed_by) REFERENCES users(id)
            )
        ''')
        
        # Tabla de notificaciones (LexNET, sistema, etc)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                type TEXT NOT NULL,  -- 'lexnet', 'system', 'document_saved', 'email'
                title TEXT NOT NULL,
                body TEXT,
                deadline DATE,
                urgency TEXT,  -- 'CRITICAL', 'URGENT', 'WARNING', 'NORMAL'
                procedure_number TEXT,
                court TEXT,
                read BOOLEAN DEFAULT 0,
                archived BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        # Tabla de documentos guardados
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS saved_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                file_path TEXT NOT NULL,
                client_name TEXT,
                doc_type TEXT,
                doc_date DATE,
                expedient TEXT,
                court TEXT,
                year INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by INTEGER,
                FOREIGN KEY (created_by) REFERENCES users(id)
            )
        ''')

        # Tabla de Expedientes (v3.0.0)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS expedientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                numero TEXT UNIQUE NOT NULL,
                cliente TEXT NOT NULL,
                contrario TEXT,
                juzgado TEXT,
                resumen TEXT,
                estado TEXT DEFAULT 'abierto',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Tabla de Notas y Feedback (v3.0.0 EVO)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS case_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                expediente_id INTEGER,
                contenido TEXT NOT NULL,
                tipo TEXT DEFAULT 'estratégica', -- 'estratégica', 'feedback_ia'
                score INTEGER DEFAULT 0,         -- -1 (corregir), 1 (bueno)
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (expediente_id) REFERENCES expedientes(id)
            )
        ''')
        
        conn.commit()
        conn.close()
        print("✅ Base de datos inicializada (v3.0.0 PRO)")
    
    def get_connection(self):
        """Obtener conexión a BD con row factory"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    # ==========================================
    # MÉTODOS DE USUARIOS
    # ==========================================
    
    def create_user(self, email: str, password_hash: str, rol: str = 'LECTURA', nombre: str = None) -> int:
        """Crear nuevo usuario"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO users (email, password_hash, rol, nombre)
            VALUES (?, ?, ?, ?)
        ''', (email, password_hash, rol, nombre))
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return user_id
    
    def get_user_by_email(self, email: str) -> Optional[Dict]:
        """Obtener usuario por email"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return dict(row)
        return None
    
    def get_user_by_id(self, user_id: int) -> Optional[Dict]:
        """Obtener usuario por ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return dict(row)
        return None
    
    def update_last_login(self, user_id: int):
        """Actualizar timestamp de último login"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE users 
            SET last_login = CURRENT_TIMESTAMP 
            WHERE id = ?
        ''', (user_id,))
        
        conn.commit()
        conn.close()
    
    def list_users(self) -> List[Dict]:
        """Listar todos los usuarios (sin password_hash)"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, email, rol, nombre, activo, created_at, last_login 
            FROM users 
            ORDER BY created_at DESC
        ''')
        
        users = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return users
    
    def deactivate_user(self, user_id: int):
        """Desactivar usuario"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('UPDATE users SET activo = 0 WHERE id = ?', (user_id,))
        conn.commit()
        conn.close()
    
    # ==========================================
    # MÉTODOS DE TOKEN BLACKLIST
    # ==========================================
    
    def add_to_blacklist(self, jti: str):
        """Añadir token a blacklist (para logout)"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('INSERT INTO token_blacklist (jti) VALUES (?)', (jti,))
        conn.commit()
        conn.close()
    
    def is_token_blacklisted(self, jti: str) -> bool:
        """Verificar si token está en blacklist"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT id FROM token_blacklist WHERE jti = ?', (jti,))
        result = cursor.fetchone()
        conn.close()
        
        return result is not None
    
    # ==========================================
    # MÉTODOS DE AUDITORÍA
    # ==========================================
    
    def log_action(self, user_id: int, action: str, endpoint: str = None, ip_address: str = None):
        """Registrar acción en log de auditoría"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO audit_log (user_id, action, endpoint, ip_address)
            VALUES (?, ?, ?, ?)
        ''', (user_id, action, endpoint, ip_address))
        
        conn.commit()
        conn.close()
    
    def get_audit_log(self, user_id: int = None, limit: int = 100) -> List[Dict]:
        """Obtener log de auditoría"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        if user_id:
            cursor.execute('''
                SELECT * FROM audit_log 
                WHERE user_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (user_id, limit))
        else:
            cursor.execute('''
                SELECT * FROM audit_log 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (limit,))
        
        logs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return logs
    
    # ==========================================
    # MÉTODOS DE DOCUMENTOS
    # ==========================================
    
    def create_pending_document(self, temp_file_path: str, original_filename: str, 
                                extracted_data: str = None, proposed_data: str = None) -> int:
        """Crear documento pendiente de revisión"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO pending_documents (temp_file_path, original_filename, extracted_data, proposed_data)
            VALUES (?, ?, ?, ?)
        ''', (temp_file_path, original_filename, extracted_data, proposed_data))
        
        doc_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return doc_id
    
    def get_pending_documents(self, status: str = 'pending', limit: int = 50) -> List[Dict]:
        """Obtener documentos pendientes"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM pending_documents 
            WHERE status = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (status, limit))
        
        docs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return docs
    
    def count_pending_documents(self) -> int:
        """Contar documentos pendientes"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) as count FROM pending_documents WHERE status = 'pending'")
        result = cursor.fetchone()
        conn.close()
        
        return result['count'] if result else 0
    
    def update_pending_document_status(self, doc_id: int, status: str, processed_by: int = None):
        """Actualizar estado de documento pendiente"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE pending_documents 
            SET status = ?, processed_at = CURRENT_TIMESTAMP, processed_by = ?
            WHERE id = ?
        ''', (status, processed_by, doc_id))
        
        conn.commit()
        conn.close()
    
    def create_saved_document(self, filename: str, file_path: str, client_name: str = None,
                             doc_type: str = None, doc_date: str = None, expedient: str = None,
                             court: str = None, year: int = None, created_by: int = None) -> int:
        """Crear registro de documento guardado"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO saved_documents 
            (filename, file_path, client_name, doc_type, doc_date, expedient, court, year, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (filename, file_path, client_name, doc_type, doc_date, expedient, court, year, created_by))
        
        doc_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return doc_id
    
    def get_saved_documents(self, limit: int = 50) -> List[Dict]:
        """Obtener documentos guardados recientes"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM saved_documents 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (limit,))
        
        docs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return docs
    
    def count_documents_today(self) -> int:
        """Contar documentos guardados hoy"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*) as count FROM saved_documents 
            WHERE DATE(created_at) = DATE('now')
        ''')
        result = cursor.fetchone()
        conn.close()
        
        return result['count'] if result else 0
    
    def get_documents_by_client(self, client_name: str) -> List[Dict]:
        """Obtener documentos de un cliente"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM saved_documents 
            WHERE client_name LIKE ? 
            ORDER BY created_at DESC
        ''', (f'%{client_name}%',))
        
        docs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return docs

    # ==========================================
    # MÉTODOS DE EXPEDIENTES (v3.0.0)
    # ==========================================

    def create_expediente(self, numero: str, cliente: str, contrario: str = None, 
                          juzgado: str = None, resumen: str = None) -> int:
        """Crear nuevo expediente"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO expedientes (numero, cliente, contrario, juzgado, resumen)
            VALUES (?, ?, ?, ?, ?)
        ''', (numero, cliente, contrario, juzgado, resumen))
        exp_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return exp_id

    def get_expediente(self, expediente_id: int) -> Optional[Dict]:
        """Obtener expediente por ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM expedientes WHERE id = ?', (expediente_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def get_documentos_by_expediente(self, numero_expediente: str, limit: int = 10) -> List[Dict]:
        """Obtener documentos asociados a un número de expediente"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM saved_documents 
            WHERE expedient = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (numero_expediente, limit))
        docs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return docs

    def add_case_note(self, expediente_id: int, contenido: str, tipo: str = 'estratégica', score: int = 0) -> int:
        """Añadir nota o feedback a un expediente"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO case_notes (expediente_id, contenido, tipo, score)
            VALUES (?, ?, ?, ?)
        ''', (expediente_id, contenido, tipo, score))
        note_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return note_id

    def get_notas_by_expediente(self, expediente_id: int) -> List[Dict]:
        """Obtener notas de un expediente"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM case_notes 
            WHERE expediente_id = ? 
            ORDER BY created_at DESC
        ''', (expediente_id,))
        notes = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return notes
