"""
AI Agent Service - Orquestador de inteligencia contextual (v3.0.0)
Coordina la recolección de contexto de la DB y documentos previos para una generación inteligente.
"""
import os
import json
from datetime import datetime
from typing import List, Dict, Optional

class AIAgentService:
    def __init__(self, ai_service, db_manager):
        self.ai = ai_service
        self.db = db_manager
        self.memory_limit = 5 # Documentos previos a consultar

    def get_case_context(self, expediente_id: str) -> str:
        """
        Recuperar el contexto completo de un expediente para la IA.
        Combina metadata de la DB, notas de estrategia y FEEDBACK previo (v3.0.0 EVO).
        """
        context_parts = []
        
        # 1. Obtener datos básicos del expediente
        case_data = self.db.get_expediente(expediente_id)
        if case_data:
            context_parts.append(f"EXPEDIENTE: {case_data.get('numero', 'N/A')}")
            context_parts.append(f"CLIENTE: {case_data.get('cliente', 'N/A')}")
            context_parts.append(f"CONTRARIO: {case_data.get('contrario', 'N/A')}")
            context_parts.append(f"JUZGADO: {case_data.get('juzgado', 'N/A')}")
            context_parts.append(f"RESUMEN CASO: {case_data.get('resumen', 'Sin resumen')}")

        # 2. Obtener documentos previos (historial)
        docs = self.db.get_documentos_by_expediente(expediente_id, limit=self.memory_limit)
        if docs:
            context_parts.append("\nHISTORIAL DE DOCUMENTOS:")
            for d in docs:
                context_parts.append(f"- {d.get('fecha')}: {d.get('tipo')} ({d.get('resumen', 'Sin resumen')})")

        # 3. Obtener notas y feedback
        all_notes = self.db.get_notas_by_expediente(expediente_id)
        
        # Separar estrategia de feedback para dar prioridad en el prompt
        strategy = [n for n in all_notes if n.get('tipo') == 'estratégica']
        feedback = [n for n in all_notes if n.get('tipo') == 'feedback_ia']

        if strategy:
            context_parts.append("\nESTRATEGIA LEGAL PREVIA:")
            for n in strategy:
                context_parts.append(f"- {n.get('contenido')}")

        if feedback:
            context_parts.append("\nAPRENDIZAJE / CORRECCIONES PREVIAS (CRÍTICO):")
            for n in feedback:
                sentiment = "CORRECCIÓN" if n.get('score', 0) < 0 else "PREFERENCIA"
                context_parts.append(f"- [{sentiment}] {n.get('contenido')}")

        return "\n".join(context_parts)

    def propose_next_action(self, context: str) -> Dict:
        """El agente analiza el contexto y sugiere qué documento redactar"""
        prompt = f"""Analiza el siguiente contexto de un expediente legal y sugiere la PRÓXIMA ACCIÓN necesaria (ej: presentar recurso, contestar demanda, pedir prueba).

CONTEXTO:
{context}

Responde SOLO en JSON:
{{
  "sugerencia": "título de la acción",
  "razonamiento": "por qué es necesaria esta acción",
  "urgencia": "alta/media/baja",
  "tipo_documento_id": "id_del_template"
}}"""
        
        result = self.ai.chat_cascade(prompt, mode='creative')
        if result.get('success'):
            try:
                # Extraer JSON de la respuesta
                import re
                json_match = re.search(r'\{[^{}]*\}', result['response'], re.DOTALL)
                if json_match:
                    return json.loads(json_match.group())
            except: pass
            
        return {"sugerencia": "Revisar expediente", "razonamiento": "No se pudo determinar acción automática", "urgencia": "media"}

    def generate_draft(self, expediente_id: str, doc_type: str, user_instructions: str = ""):
        """Generar un borrador de documento inyectando el contexto completo del expediente"""
        context = self.get_case_context(expediente_id)
        
        # Este método será usado por el DocumentGenerator refactoreado
        return {
            "expediente_id": expediente_id,
            "context": context,
            "doc_type": doc_type,
            "instructions": user_instructions
        }
